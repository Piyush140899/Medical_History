# Medical_History #node_js #Mysql
A Personal Medical history Tracking system.<br/>
**Features**
- General Information regarding the patient. 
- Ability to form Family Groups.
- Tracking Hereditary diseases.
- Accident Recovery tracking.
- Intutive UI design.
